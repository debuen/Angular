app.controller('topController', ["$scope", 
   function($scope){
       $scope.title = "LISTAME";
   } 
]);

